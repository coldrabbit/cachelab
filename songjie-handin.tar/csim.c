/***
 * editor: 宋杰
 * time: 2020.1.3
 * function: cache simulator
 ***/
#include "cachelab.h"
#include <stdlib.h>
#include <stdio.h>
#include <getopt.h>
#include <string.h>

int hit_count, miss_count, eviction_count;//需要输出的三个参数，分别为命中数、缺失数、清出数

int h,v,s,E,b,S;//传递进来的参数

typedef struct{
    int validBit;//有效位
    int tag;//标记位
    int LRU_counter;//时间戳
}cache_line, *cache;//cache的结构

cache *cache_p = NULL;//cache的指针

char t[32];

void printHelp(){//输出提示信息
    printf("Usage: ./csim [-hv] -s <num> -E <num> -b <num> -t <file>\n"
           "Options:\n"
           "  -h         Print this help message.\n"
           "  -v         Optional verbose flag.\n"
           "  -s <num>   Number of set index bits.\n"
           "  -E <num>   Number of lines per set.\n"
           "  -b <num>   Number of block offset bits.\n"
           "  -t <file>  Trace file.\n\n"
           "Examples:\n"
           "  linux>  ./csim -s 4 -E 1 -b 4 -t traces/yi.trace\n"
           "  linux>  ./csim -v -s 8 -E 2 -b 4 -t traces/yi.trace\n");
}

void init_cache(){//初始化cache
    cache_p = (cache *)malloc(sizeof(cache)*S);
    int i, j;
    for(i = 0; i < S; i++){
        cache_p[i] = (cache_line *)malloc(sizeof(cache_line)*E);
        for(j = 0; j < E; j++){
            cache_p[i][j].validBit = 0;
            cache_p[i][j].tag = -1;
            cache_p[i][j].LRU_counter = -1;
        }
    }
}

void update(unsigned int address){//更新cache的内容
    int setindex = (address << (64 - b -s)) >> (64 - s);
    int tag = address >> (b+s);
    int max_LRU_counter = -2;
    int max_LRU_counter_index;
    int i;

    for(i = 0; i < E; i++){
        if(cache_p[setindex][i].tag == tag){//tag相同，命中
            cache_p[setindex][i].LRU_counter = 0;
            hit_count++;
            return;
        }
    }

    for(i = 0; i < E; i++){
        if(cache_p[setindex][i].validBit == 0){//有空行
            cache_p[setindex][i].validBit = 1;
            cache_p[setindex][i].tag = tag;
            cache_p[setindex][i].LRU_counter = 0;
            miss_count++;
            return;
        }
    }

    eviction_count++;
    miss_count++;
    for(i = 0; i<E; i++){
        if(cache_p[setindex][i].LRU_counter > max_LRU_counter){
            max_LRU_counter = cache_p[setindex][i].LRU_counter;
            max_LRU_counter_index = i;
        }
    }
    cache_p[setindex][max_LRU_counter_index].tag = tag;
    cache_p[setindex][max_LRU_counter_index].LRU_counter = 0;
    return;
}

void update_LRU_count(){
    int i, j;
    for(i = 0; i < S; i++){
        for(j = 0; j < E; j++){
            if(cache_p[i][j].validBit == 1)
                cache_p[i][j].LRU_counter++;
        }
    }
}

void trace(){
    FILE *fp = fopen(t, "r");
    if(fp == NULL){
        printf("file open failed\n");
        exit(-1);
    }

    char operation;//命令参数
    unsigned int address;//地址参数
    int size;//大小参数

    while(fscanf(fp, "%c %xu,%d\n", &operation, &address, &size)){
        switch(operation){
            case 'I':
                continue;
            case 'L':
                update(address);
                break;
            case 'M'://a data load followed by a data store
                update(address);
            case 'S':
                update(address);
                break;
        }
        update_LRU_count();
    }

    fclose(fp);

    int i;
    for(i = 0; i < S; i++){
        free(cache_p[i]);
    }
    free(cache_p);//释放init_cache中申请的空间，防止内存泄漏
}

int main(int argc, char* argv[])
{
    hit_count = miss_count = eviction_count = 0;
    h = 0;
    v = 0;
    int opt;

    while((opt = getopt(argc, argv, "hvs:E:b:t:")) != -1){//获取参数
        switch(opt){
            case 'h':
                h = 1;
                printHelp();
                break;
            case 'v':
                v = 1;
                printHelp();
                break;
            case 's':
                s = atoi(optarg);
                break;
            case 'E':
                E = atoi(optarg);
                break;
            case 'b':
                b = atoi(optarg);
                break;
            case 't':
                strcpy(t, optarg);
                break;
            default:
                printHelp();
                break;
        }
    }

    if(s<=0 || E<=0 || b<=0 || t==NULL)
        return -1;

    S = 1<<s;//S = 2^s is the number of sets

    FILE* fp = fopen(t, "r");
    if(fp == NULL){
        printf("file open failed\n");
        return -1;
    }

    init_cache();
    trace();
    printSummary(hit_count, miss_count, eviction_count);

    return 0;
}
